// Educational Book Apps - Main JavaScript File
// Handles all interactive functionality and user experience enhancements

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initMobileNavigation();
    initSearch();
    initLazyLoading();
    initSmoothScrolling();
    initFilterFunctionality();
    initStickyDownloadButton();
    initAnimations();
    initAdSenseIntegration();
    
    console.log('Educational Book Apps - Website loaded successfully');
});

// Mobile Navigation Toggle
function initMobileNavigation() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const navList = document.querySelector('.nav-list');
    
    if (mobileToggle && navList) {
        mobileToggle.addEventListener('click', function() {
            navList.classList.toggle('active');
            
            // Animate hamburger menu
            const spans = mobileToggle.querySelectorAll('span');
            spans.forEach((span, index) => {
                if (navList.classList.contains('active')) {
                    if (index === 0) span.style.transform = 'rotate(45deg) translate(5px, 5px)';
                    if (index === 1) span.style.opacity = '0';
                    if (index === 2) span.style.transform = 'rotate(-45deg) translate(7px, -6px)';
                } else {
                    span.style.transform = '';
                    span.style.opacity = '';
                }
            });
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!mobileToggle.contains(e.target) && !navList.contains(e.target)) {
                navList.classList.remove('active');
                const spans = mobileToggle.querySelectorAll('span');
                spans.forEach(span => {
                    span.style.transform = '';
                    span.style.opacity = '';
                });
            }
        });
    }
}

// Search Functionality
function initSearch() {
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    
    if (searchInput && searchButton) {
        // Search button click
        searchButton.addEventListener('click', performSearch);
        
        // Enter key press
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        
        // Real-time search suggestions (if on class listing pages)
        if (document.querySelector('.apps-grid')) {
            searchInput.addEventListener('input', function() {
                const query = this.value.toLowerCase().trim();
                filterApps(query);
            });
        }
    }
}

function performSearch() {
    const searchInput = document.getElementById('search-input');
    const query = searchInput.value.toLowerCase().trim();
    
    if (query === '') {
        showNotification('Please enter a search term', 'warning');
        return;
    }
    
    // If we're on the home page, redirect to search results
    if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
        // For demo purposes, redirect to class-1 if searching for math/english
        if (query.includes('math') || query.includes('mathematics')) {
            window.location.href = '/class-1/app-math.html';
        } else if (query.includes('english') || query.includes('language')) {
            window.location.href = '/class-1/app-english.html';
        } else if (query.includes('science')) {
            window.location.href = '/class-2/app-science.html';
        } else {
            // Generic search - go to class 1
            window.location.href = '/class-1/';
        }
    } else {
        // If we're on a class page, filter the apps
        filterApps(query);
    }
}

function filterApps(query) {
    const appCards = document.querySelectorAll('.app-card');
    let visibleCount = 0;
    
    appCards.forEach(card => {
        const title = card.querySelector('.app-title')?.textContent.toLowerCase() || '';
        const description = card.querySelector('.app-description')?.textContent.toLowerCase() || '';
        const subject = card.querySelector('.app-subject')?.textContent.toLowerCase() || '';
        
        const isVisible = title.includes(query) || 
                         description.includes(query) || 
                         subject.includes(query);
        
        if (isVisible) {
            card.style.display = 'block';
            card.classList.add('fade-in-up');
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    // Show no results message if needed
    showSearchResults(visibleCount, query);
}

function showSearchResults(count, query) {
    let resultsMessage = document.querySelector('.search-results-message');
    
    if (!resultsMessage) {
        resultsMessage = document.createElement('div');
        resultsMessage.className = 'search-results-message';
        const appsGrid = document.querySelector('.apps-grid');
        if (appsGrid) {
            appsGrid.parentNode.insertBefore(resultsMessage, appsGrid);
        }
    }
    
    if (query === '') {
        resultsMessage.style.display = 'none';
    } else {
        resultsMessage.style.display = 'block';
        resultsMessage.innerHTML = count > 0 
            ? `<p>Found ${count} app${count !== 1 ? 's' : ''} matching "${query}"</p>`
            : `<p>No apps found matching "${query}". Try a different search term.</p>`;
    }
}

// Lazy Loading for Images
function initLazyLoading() {
    const images = document.querySelectorAll('img[loading="lazy"]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.src || img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => {
            imageObserver.observe(img);
        });
    } else {
        // Fallback for older browsers
        images.forEach(img => {
            img.src = img.src || img.dataset.src;
        });
    }
}

// Smooth Scrolling
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Filter Functionality for Class Pages
function initFilterFunctionality() {
    const subjectFilter = document.getElementById('subject-filter');
    const sortFilter = document.getElementById('sort-filter');
    
    if (subjectFilter) {
        subjectFilter.addEventListener('change', function() {
            filterBySubject(this.value);
        });
    }
    
    if (sortFilter) {
        sortFilter.addEventListener('change', function() {
            sortApps(this.value);
        });
    }
}

function filterBySubject(subject) {
    const appCards = document.querySelectorAll('.app-card');
    
    appCards.forEach(card => {
        const cardSubject = card.dataset.subject;
        
        if (subject === 'all' || cardSubject === subject) {
            card.style.display = 'block';
            card.classList.add('fade-in-up');
        } else {
            card.style.display = 'none';
        }
    });
}

function sortApps(sortBy) {
    const appsGrid = document.querySelector('.apps-grid');
    if (!appsGrid) return;
    
    const appCards = Array.from(appsGrid.querySelectorAll('.app-card'));
    
    appCards.sort((a, b) => {
        switch (sortBy) {
            case 'name':
                const nameA = a.querySelector('.app-title').textContent;
                const nameB = b.querySelector('.app-title').textContent;
                return nameA.localeCompare(nameB);
                
            case 'rating':
                const ratingA = parseFloat(a.querySelector('.app-rating').textContent.split(' ')[1]);
                const ratingB = parseFloat(b.querySelector('.app-rating').textContent.split(' ')[1]);
                return ratingB - ratingA;
                
            case 'popular':
                const downloadsA = parseInt(a.querySelector('.app-downloads').textContent.replace(/\D/g, ''));
                const downloadsB = parseInt(b.querySelector('.app-downloads').textContent.replace(/\D/g, ''));
                return downloadsB - downloadsA;
                
            case 'newest':
                // For demo purposes, reverse the current order
                return 0;
                
            default:
                return 0;
        }
    });
    
    // Re-append sorted cards
    appCards.forEach(card => {
        appsGrid.appendChild(card);
        card.classList.add('fade-in-up');
    });
}

// Sticky Download Button
function initStickyDownloadButton() {
    const stickyBtn = document.querySelector('.sticky-download-btn');
    
    if (stickyBtn && window.innerWidth <= 768) {
        let lastScrollTop = 0;
        
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            if (scrollTop > 300) {
                if (scrollTop > lastScrollTop) {
                    // Scrolling down
                    stickyBtn.style.transform = 'translateY(100px)';
                } else {
                    // Scrolling up
                    stickyBtn.style.transform = 'translateY(0)';
                }
            } else {
                stickyBtn.style.transform = 'translateY(100px)';
            }
            
            lastScrollTop = scrollTop;
        });
    }
}

// Animations on Scroll
function initAnimations() {
    const animatedElements = document.querySelectorAll('.class-card, .featured-app, .app-card');
    
    if ('IntersectionObserver' in window) {
        const animationObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                    animationObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        animatedElements.forEach(element => {
            animationObserver.observe(element);
        });
    }
}

// AdSense Integration Placeholder
function initAdSenseIntegration() {
    // This function would handle real AdSense integration
    // For now, we'll just add some interactive behavior to ad slots
    
    const adSlots = document.querySelectorAll('.adsense-ad-slot');
    
    adSlots.forEach(slot => {
        // Add click tracking for demo purposes
        slot.addEventListener('click', function() {
            console.log('Ad slot clicked:', this.dataset.adSlot);
            // In real implementation, this would track ad interactions
        });
        
        // Simulate ad loading
        setTimeout(() => {
            slot.classList.add('ad-loaded');
        }, Math.random() * 2000 + 1000);
    });
}

// Utility Functions

// Show notification messages
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        borderRadius: '0.5rem',
        color: 'white',
        fontWeight: '500',
        zIndex: '9999',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease'
    });
    
    // Set background color based on type
    switch (type) {
        case 'success':
            notification.style.backgroundColor = '#10b981';
            break;
        case 'warning':
            notification.style.backgroundColor = '#f59e0b';
            break;
        case 'error':
            notification.style.backgroundColor = '#ef4444';
            break;
        default:
            notification.style.backgroundColor = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Download tracking
function trackDownload(appName, downloadType) {
    console.log(`Download tracked: ${appName} - ${downloadType}`);
    
    // Show success notification
    showNotification(`Starting download: ${appName}`, 'success');
    
    // In real implementation, this would send analytics data
    // Example: gtag('event', 'download', { app_name: appName, download_type: downloadType });
}

// Add download tracking to all download links
document.addEventListener('click', function(e) {
    if (e.target.matches('a[download], a[href*=".apk"]')) {
        const appName = document.querySelector('.app-title')?.textContent || 'Unknown App';
        const downloadType = e.target.href.includes('.apk') ? 'APK' : 'Package';
        trackDownload(appName, downloadType);
    }
});

// Web version tracking
document.addEventListener('click', function(e) {
    if (e.target.matches('a[href*="/flutter-web/"]')) {
        const appName = document.querySelector('.app-title')?.textContent || 'Unknown App';
        console.log(`Web version opened: ${appName}`);
        showNotification(`Opening web version: ${appName}`, 'info');
    }
});

// Form validation (if contact forms are added later)
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
        } else {
            input.classList.remove('error');
        }
    });
    
    return isValid;
}

// Performance monitoring
function measurePerformance() {
    if ('performance' in window) {
        window.addEventListener('load', function() {
            setTimeout(() => {
                const perfData = performance.getEntriesByType('navigation')[0];
                console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
                console.log('DOM content loaded:', perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart, 'ms');
            }, 0);
        });
    }
}

// Initialize performance monitoring
measurePerformance();

// Service Worker registration (for future PWA features)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment when service worker is implemented
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered'))
        //     .catch(error => console.log('SW registration failed'));
    });
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // In production, this would send error reports to monitoring service
});

// Accessibility improvements
function initAccessibility() {
    // Add keyboard navigation for custom elements
    const interactiveElements = document.querySelectorAll('.class-card, .app-card, .featured-app');
    
    interactiveElements.forEach(element => {
        if (!element.hasAttribute('tabindex')) {
            element.setAttribute('tabindex', '0');
        }
        
        element.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const link = this.querySelector('a');
                if (link) {
                    link.click();
                }
            }
        });
    });
    
    // Add skip to main content link
    const skipLink = document.createElement('a');
    skipLink.href = '#main';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'skip-link';
    skipLink.style.cssText = `
        position: absolute;
        top: -40px;
        left: 6px;
        background: #000;
        color: #fff;
        padding: 8px;
        text-decoration: none;
        z-index: 10000;
        transition: top 0.3s;
    `;
    
    skipLink.addEventListener('focus', function() {
        this.style.top = '6px';
    });
    
    skipLink.addEventListener('blur', function() {
        this.style.top = '-40px';
    });
    
    document.body.insertBefore(skipLink, document.body.firstChild);
}

// Initialize accessibility features
initAccessibility();

// Export functions for testing (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        performSearch,
        filterApps,
        showNotification,
        debounce,
        throttle
    };
}

