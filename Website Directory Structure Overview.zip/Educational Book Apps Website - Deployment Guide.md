# Educational Book Apps Website - Deployment Guide

## 📋 Overview

This guide provides step-by-step instructions for deploying your Educational Book Apps website to production. The website is built with modern HTML5, CSS3, and JavaScript, optimized for performance, SEO, and mobile responsiveness.

## 🏗️ Website Structure

```
root_website/
├── index.html                 # Homepage
├── class-1/
│   ├── index.html            # Class 1 listing page
│   ├── app-math.html         # Math app detail page
│   └── app-english.html      # English app detail page
├── class-2/
│   └── app-science.html      # Science app detail page
├── flutter-web/              # Flutter web app hosting directory
├── downloads/                # APK files directory
├── assets/
│   ├── css/
│   │   └── styles.css        # Main stylesheet
│   └── images/               # Image assets directory
├── scripts/
│   └── main.js              # Main JavaScript file
├── ads.txt                  # AdSense verification
├── sitemap.xml             # SEO sitemap
├── robots.txt              # Search engine directives
├── 404.html                # Custom error page
└── site.webmanifest        # PWA manifest
```

## 🚀 Deployment Options

### Option 1: Netlify (Recommended)

1. **Prepare Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin YOUR_REPO_URL
   git push -u origin main
   ```

2. **Deploy to Netlify**
   - Connect your GitHub repository to Netlify
   - Build settings: None required (static site)
   - Publish directory: `root_website`
   - Custom domain: Configure your domain in Netlify settings

3. **Configure Redirects**
   Create `_redirects` file in root_website:
   ```
   /*    /404.html   404
   ```

### Option 2: Vercel

1. **Install Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **Deploy**
   ```bash
   cd root_website
   vercel --prod
   ```

### Option 3: Firebase Hosting

1. **Install Firebase CLI**
   ```bash
   npm install -g firebase-tools
   firebase login
   ```

2. **Initialize Project**
   ```bash
   firebase init hosting
   # Select root_website as public directory
   # Configure as single-page app: No
   # Set up automatic builds: No
   ```

3. **Deploy**
   ```bash
   firebase deploy
   ```

### Option 4: Traditional Web Hosting

1. **Upload Files**
   - Upload all files from `root_website/` to your web server's public directory
   - Ensure proper file permissions (644 for files, 755 for directories)

2. **Configure Server**
   - Set up custom 404 error page to point to `/404.html`
   - Enable GZIP compression
   - Set proper MIME types

## ⚙️ Configuration Steps

### 1. Domain Configuration

Replace all instances of `yourdomain.com` with your actual domain:

**Files to update:**
- `index.html` (canonical URL, OpenGraph, structured data)
- `class-1/app-math.html` (canonical URL)
- `class-1/app-english.html` (canonical URL)
- `class-2/app-science.html` (canonical URL)
- `sitemap.xml` (all URLs)
- `robots.txt` (sitemap URL)

**Search and replace:**
```bash
find . -type f -name "*.html" -o -name "*.xml" -o -name "*.txt" | xargs sed -i 's/yourdomain\.com/YOUR_ACTUAL_DOMAIN/g'
```

### 2. Google AdSense Setup

1. **Get AdSense Publisher ID**
   - Apply for Google AdSense account
   - Get your publisher ID (format: pub-1234567890123456)

2. **Update ads.txt**
   ```
   google.com, pub-YOUR_PUBLISHER_ID, DIRECT, f08c47fec0942fa0
   ```

3. **Add AdSense Code**
   Replace ad placeholders in HTML files with actual AdSense code:
   ```html
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_PUBLISHER_ID" crossorigin="anonymous"></script>
   ```

### 3. Image Assets

Create and upload the following images to `/assets/images/`:

**Required Images:**
- `math-app-thumb.jpg` (300x200px)
- `english-app-thumb.jpg` (300x200px)
- `science-app-thumb.jpg` (300x200px)
- `math-app-icon.png` (120x120px)
- `english-app-icon.png` (120x120px)
- `science-app-icon.png` (120x120px)
- `og-image.jpg` (1200x630px) - For social sharing
- `twitter-image.jpg` (1200x600px) - For Twitter cards

**App Screenshots:**
- `math-app-screenshot1.jpg`
- `math-app-screenshot2.jpg`
- `math-app-screenshot3.jpg`
- `english-app-screenshot1.jpg`
- `english-app-screenshot2.jpg`
- `english-app-screenshot3.jpg`
- `science-app-screenshot1.jpg`
- `science-app-screenshot2.jpg`
- `science-app-screenshot3.jpg`

**Favicon Files (place in root):**
- `favicon.ico`
- `apple-touch-icon.png` (180x180px)
- `favicon-32x32.png`
- `favicon-16x16.png`
- `android-chrome-192x192.png`
- `android-chrome-512x512.png`

### 4. Download Links Configuration

Update download links in app detail pages:

1. **Upload APK files** to `/downloads/` directory
2. **Update links** in HTML files:
   - `math-app-class1.apk`
   - `english-app-class1.apk`
   - `science-app-class2.apk`

### 5. Flutter Web Apps

1. **Build Flutter apps** for web
2. **Upload builds** to `/flutter-web/` directory:
   - `/flutter-web/math-app-class1/`
   - `/flutter-web/english-app-class1/`
   - `/flutter-web/science-app-class2/`

## 📊 Analytics Setup

### Google Analytics 4

1. **Create GA4 Property**
2. **Add tracking code** to all HTML files before `</head>`:
   ```html
   <!-- Google tag (gtag.js) -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
   <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'GA_MEASUREMENT_ID');
   </script>
   ```

### Search Console

1. **Verify domain** in Google Search Console
2. **Submit sitemap**: `https://yourdomain.com/sitemap.xml`
3. **Monitor indexing** and search performance

## 🔒 Security Configuration

### HTTPS Setup

1. **SSL Certificate**
   - Use Let's Encrypt for free SSL
   - Configure automatic renewal

2. **Security Headers**
   Add to server configuration:
   ```
   X-Content-Type-Options: nosniff
   X-Frame-Options: DENY
   X-XSS-Protection: 1; mode=block
   Referrer-Policy: strict-origin-when-cross-origin
   ```

### Content Security Policy

Add CSP header:
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://pagead2.googlesyndication.com https://www.googletagmanager.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self';
```

## 🎯 Performance Optimization

### Server Configuration

1. **Enable GZIP Compression**
   ```apache
   # Apache .htaccess
   <IfModule mod_deflate.c>
       AddOutputFilterByType DEFLATE text/plain
       AddOutputFilterByType DEFLATE text/html
       AddOutputFilterByType DEFLATE text/xml
       AddOutputFilterByType DEFLATE text/css
       AddOutputFilterByType DEFLATE application/xml
       AddOutputFilterByType DEFLATE application/xhtml+xml
       AddOutputFilterByType DEFLATE application/rss+xml
       AddOutputFilterByType DEFLATE application/javascript
       AddOutputFilterByType DEFLATE application/x-javascript
   </IfModule>
   ```

2. **Browser Caching**
   ```apache
   # Apache .htaccess
   <IfModule mod_expires.c>
       ExpiresActive on
       ExpiresByType text/css "access plus 1 year"
       ExpiresByType application/javascript "access plus 1 year"
       ExpiresByType image/png "access plus 1 year"
       ExpiresByType image/jpg "access plus 1 year"
       ExpiresByType image/jpeg "access plus 1 year"
   </IfModule>
   ```

### CDN Setup (Optional)

1. **Cloudflare** (Free tier available)
   - Configure DNS through Cloudflare
   - Enable auto-minification
   - Enable Brotli compression

## 📱 Mobile App Integration

### PWA Features

The website includes PWA manifest (`site.webmanifest`). Users can:
- Install as app on mobile devices
- Access offline (with service worker implementation)
- Receive push notifications (future feature)

### App Store Optimization

1. **Meta App Store Tags**
   ```html
   <meta name="apple-itunes-app" content="app-id=YOUR_APP_ID">
   <meta name="google-play-app" content="app-id=YOUR_PACKAGE_NAME">
   ```

## 🔧 Maintenance

### Regular Updates

1. **Content Updates**
   - Add new apps and classes
   - Update app descriptions and screenshots
   - Refresh download links

2. **SEO Maintenance**
   - Update sitemap.xml when adding new pages
   - Monitor search console for errors
   - Update meta descriptions based on performance

3. **Performance Monitoring**
   - Use Google PageSpeed Insights
   - Monitor Core Web Vitals
   - Optimize images and assets

### Backup Strategy

1. **Automated Backups**
   - Set up daily backups of website files
   - Include database if dynamic content is added

2. **Version Control**
   - Maintain Git repository
   - Tag releases for easy rollback

## 📞 Support and Troubleshooting

### Common Issues

1. **404 Errors**
   - Ensure custom 404 page is configured
   - Check file permissions and paths

2. **AdSense Issues**
   - Verify ads.txt file is accessible
   - Check ad placement policies
   - Monitor AdSense dashboard for violations

3. **Performance Issues**
   - Optimize images (WebP format recommended)
   - Enable compression and caching
   - Use CDN for static assets

### Contact Information

For technical support or questions about this deployment:
- Review the test results in `test_results.md`
- Check browser console for JavaScript errors
- Validate HTML and CSS using W3C validators

## ✅ Pre-Launch Checklist

- [ ] Domain configured and DNS propagated
- [ ] SSL certificate installed and working
- [ ] All placeholder content replaced with real content
- [ ] AdSense account approved and ads.txt updated
- [ ] Google Analytics configured and tracking
- [ ] Search Console verified and sitemap submitted
- [ ] All images optimized and uploaded
- [ ] Download links tested and working
- [ ] Mobile responsiveness tested on real devices
- [ ] Cross-browser testing completed
- [ ] Performance optimization applied
- [ ] Security headers configured
- [ ] Backup system in place

## 🎉 Launch

Once all checklist items are completed:

1. **Soft Launch**
   - Test with limited audience
   - Monitor analytics and error logs
   - Fix any issues discovered

2. **Full Launch**
   - Announce on social media
   - Submit to relevant directories
   - Begin content marketing

3. **Post-Launch**
   - Monitor performance metrics
   - Gather user feedback
   - Plan future enhancements

---

**Congratulations!** Your Educational Book Apps website is ready for production deployment. This modern, responsive, and SEO-optimized website will serve as an excellent hub for your Flutter-based educational applications.

